package logic;

public class PoorCreditRatingException extends Exception { // ansvar:Martin review:Sofie

	public PoorCreditRatingException(String message) {
		super(message);
	}
}
